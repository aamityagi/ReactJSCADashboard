import React from 'react';
import { Routes, Route } from 'react-router-dom';
import './App.css';
import Register from './Component/Register/Register';
import Login from './Component/Login/Login';
import ForgotPassword from './Component/ForgotPassword/ForgotPassword';
import Layout from './Component/Layout/Layout';
import Dashboard from './Component/Pages/Dashboard/Dashboard';
import About from './Component/Pages/About';
import Enquire from './Component/Pages/Enquire';
import Services from './Component/Pages/Services';


function App() {
  return (
    <>
        <Routes>
          {/* Login and Registration Render First */}
          <Route path='/' element={<Login/>}></Route>
          <Route path='/register' element={<Register/>}></Route>
          <Route path='/forgot-password' element={<ForgotPassword/>}></Route>
          {/* After Login component and page Render Start in Layout */}
          <Route path='/' element={<Layout/> }>
            {/* Admin View Pages Start */}
            <Route path='/dashboard' element={<Dashboard/>}></Route>
            <Route path='/about' element={<About/>}></Route>
            <Route path='/enquire' element={<Enquire/>}></Route>
            <Route path='/services' element={<Services/>}></Route>
            {/* Admin View Pages End */}
          </Route> 
          {/* If the User or other person Search by the Url Like:- www.demo.com/test or another page **/}
          <Route path='*' element={<Login/>}></Route>
        </Routes>
    </>
  );
}

export default App;
