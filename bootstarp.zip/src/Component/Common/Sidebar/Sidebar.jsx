import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import {RiTeamLine} from 'react-icons/ri'
import {MdFeedback} from 'react-icons/md'
import {BsFillQuestionOctagonFill} from 'react-icons/bs'
const Sidebar = () => {
  const [sideBarToggle, setSideBarRoggle] = useState('');
  const sideBarOpenClose = () => {
    if(sideBarToggle === "")
    {
      setSideBarRoggle('toggled')
    }else {
      setSideBarRoggle('')
    }
    
  }
  return (
    <ul
      className={`navbar-nav bg-gradient-primary sidebar sidebar-dark accordion ${sideBarToggle}`}
      id="accordionSidebar"
    >
      {/* Sidebar - Brand */}
      <Link
        className="sidebar-brand d-flex align-items-center justify-content-center"
        to="index.html"
      >
        <div className="sidebar-brand-icon rotate-n-15">
          <i className="fas fa-laugh-wink" />
        </div>
        <div className="sidebar-brand-text mx-3">
          CA Dashbaord
        </div>
      </Link>
      {/* Divider */}
      <hr className="sidebar-divider my-0" />
      {/* Nav Item - Dashboard */}
      <li className="nav-item active">
        <Link className="nav-link" to="/dashboard">
          <i className="fas fa-fw fa-tachometer-alt" />
          <span>Dashboard</span>
        </Link>
      </li>
      {/* Divider */}
      <hr class="sidebar-divider"/>
      {/* Heading */}
      <div class="sidebar-heading">
          Important
      </div>
      {/* Nav Item - Pages Collapse Menu */}
      <li className="nav-item">
        <Link
          className="nav-link collapsed"
          to="#"
          data-toggle="collapse"
          data-target="#collapsePages"
          aria-expanded="true"
          aria-controls="collapsePages"
        >
          <i className="fas fa-solid fa-file"></i>
          <span>Pages</span>
        </Link>
        <div
          id="collapsePages"
          className="collapse"
          aria-labelledby="headingPages"
          data-parent="#accordionSidebar"
        >
          <div className="bg-white py-2 collapse-inner rounded">
            <h6 className="collapse-header">Pages</h6>
            <Link className="collapse-item" to="/about">
              Home
            </Link>
            <Link className="collapse-item" to="/about">
              About
            </Link>
            <Link className="collapse-item" to="register.html">
              Pricing
            </Link>
            <Link className="collapse-item" to="forgot-password.html">
              Contact Us
            </Link>
            <Link className="collapse-item" to="forgot-password.html">
              Blog's
            </Link>
          </div>
        </div>
      </li>
      {/* Nav Item - Pages Collapse Menu */}
      <li className="nav-item">
        <Link
          className="nav-link collapsed"
          to="#"
          data-toggle="collapse"
          data-target="#collapseTwo"
          aria-expanded="true"
          aria-controls="collapseTwo"
        >
          <i className="fas fa-fw fa-cog" />
          <span>Services</span>
        </Link>
        <div
          id="collapseTwo"
          className="collapse"
          aria-labelledby="headingTwo"
          data-parent="#accordionSidebar"
        >
          <div className="bg-white py-2 collapse-inner rounded">
            <h6 className="collapse-header">Services Request:</h6>
            <Link className="collapse-item" to="buttons.html">
              CURD Services
            </Link>
          </div>
        </div>
      </li>
      {/* Divider */}
      <hr class="sidebar-divider"/>
      {/* Heading */}
      <div class="sidebar-heading">
          Common Component
      </div>
      {/* Nav Item - Common Collapse Menu */}
      <li className="nav-item">
      <Link className="nav-link" to="#">
          <RiTeamLine/>
          <span> About Short Notes</span>
        </Link>
        <Link className="nav-link" to="#">
          <RiTeamLine/>
          <span> Team</span>
        </Link>
        <Link className="nav-link" to="#">
          <i className="fas fa-fw fa-cog" />
          <span>About Our Services</span>
        </Link>
        <Link className="nav-link" to="#">
          <MdFeedback/>
          <span> Customers Feedback</span>
        </Link>
        <Link className="nav-link" to="#">
          <BsFillQuestionOctagonFill/>
          <span> Frequently Asked Questions</span>
        </Link>
      </li>
      {/* Sidebar Toggler (Sidebar) */}
      <div className="text-center d-none d-md-inline">
        <button className="rounded-circle border-0" id="sidebarToggle" onClick={sideBarOpenClose}/>
      </div>
    </ul>
  )
}

export default Sidebar
