import React from 'react'

const AboutShortNotes = () => {
  return (
    <div>
      About Short Notes
    </div>
  )
}

export default AboutShortNotes
