import React from 'react'

const CustomersFeedback = () => {
  return (
    <div>
      Customers Feedback
    </div>
  )
}

export default CustomersFeedback
