import React from 'react'

const FrequentlyAskedQuestions = () => {
  return (
    <div>
      Frequently Asked Questions
    </div>
  )
}

export default FrequentlyAskedQuestions
