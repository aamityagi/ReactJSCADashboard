import React from 'react'

const Enquire = () => {
  return (
    <div>
      Enquiry
    </div>
  )
}

export default Enquire
