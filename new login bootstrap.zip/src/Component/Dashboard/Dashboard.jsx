import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Navigate } from 'react-router-dom';
const Dashboard = () => {
    axios.defaults.withCredentials = true;
    const [auth, setAuth] = useState(false)
    const [message, setMessage] = useState('')
    const [name, setName] = useState('')
    useEffect(() => {
        axios.get('/')
        .then(res => {
            if(res.data.status === "Success") {
                setAuth(true)
                setName(res.data.name)
                Navigate('/login')
            } else {
                setAuth(false)
                setMessage(res.data.Error)
            }
        })
        .then(err => console.log(err))
    }, [])

    const handleLogout = () => {}
  return (
    <div>
      {
        auth ?
        <div>
            <h3>Home Page You are access ------- {name}</h3>
            <button onClick={handleLogout}>Logout</button>
        </div>
        : 
        <div>
            <h1>{message}</h1>
        </div>
      }
    </div>
  )
}

export default Dashboard
