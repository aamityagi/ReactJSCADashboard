import React, { useState } from 'react'
import './Login.css'
import { Link, useNavigate } from 'react-router-dom'
import axios from 'axios'
const Login = () => {
    const [formValues, setFormValues] = useState({
        email:'',
        password:''
    })
    const navigateTo = useNavigate();
    // Axios Set Defaults Credentials
    axios.defaults.withCredentials = true;
    const handleLogin = (e) => {
        console.log(formValues)
        e.preventDefault();
        axios.post("http://localhost:3003/login",  formValues)
        .then(res => {
            if(res.data.Status === "Success"){
                navigateTo('/')
            }else{
                console.log("Error")
            }
        })
        .then(err => console.log(err))
    }
  return (
    <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-12 col-lg-10">
            <div className="wrap d-md-flex">
              <div className="img" style={{backgroundImage: 'url(images/bg-1.jpg)'}}>
              </div>
              <div className="login-wrap p-4 p-md-5">
                <div className="d-flex">
                  <div className="w-100">
                    <h3 className="mb-4">Sign In</h3>
                  </div>
                </div>
                <form onSubmit={handleLogin} className="signin-form">
                  <div className="form-group mb-3">
                    <label className="label" htmlFor="email">Email Id</label>
                    <input type="text" className="form-control" id="email" placeholder="Enter Email Id" required onChange={e => setFormValues({...formValues, email: e.target.value})}/>
                  </div>
                  <div className="form-group mb-3">
                    <label className="label" htmlFor="password">Password</label>
                    <input type="password" className="form-control" placeholder="Password" required onChange={e => setFormValues({...formValues, password: e.target.value})}/>
                  </div>
                  <div className="form-group">
                    <button type="submit" className="form-control btn btn-primary rounded submit px-3">Sign In</button>
                  </div>
                  <div className="form-group d-md-flex">
                    <div className="w-50 text-left">
                      <label className="checkbox-wrap checkbox-primary mb-0">Remember Me
                        <input type="checkbox" defaultChecked />
                        <span className="checkmark" />
                      </label>
                    </div>
                    <div className="w-50 text-md-right">
                      <Link>
                        Forgot Password
                      </Link>
                    </div>
                  </div>
                </form>
                <p className="text-center">Not a member? <Link to={"/register"}>Register</Link></p>
              </div>
            </div>
          </div>
        </div>
      </div>
  )
}

export default Login
